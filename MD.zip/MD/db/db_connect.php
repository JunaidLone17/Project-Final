<?php
	$pdo = new PDO('mysql:dbname=zoomanagement;host=localhost', 'root', '', [PDO::ATTR_ERRMODE =>  PDO::ERRMODE_EXCEPTION ]);
